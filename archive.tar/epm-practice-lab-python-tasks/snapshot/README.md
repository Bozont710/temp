to install:
- snapshot$ python setup.py bdist_egg bdist_wheel sdist

to run:
- snapshot$ cd ..
- $ pip install -U ./snapshot-util
- $ snapshot -i 1