#!/usr/bin/env python3
"""
Make snapshot

{"Tasks": {"total": 440, "running": 1, "sleeping": 354, "stopped": 1, "zombie": 0},
"%CPU": {"user": 14.4, "system": 2.2, "idle": 82.7},
"KiB Mem": {"total": 16280636, "free": 335140, "used": 11621308},
"KiB Swap": {"total": 16280636, "free": 335140, "used": 11621308},
"Timestamp": 1624400255}
"""
import argparse
import psutil
import time
import json
import os

class CreateSnap:
    snap = {"Tasks": {"total": 0, "running": 0, "sleeping": 0, "stopped": 0, "zombie": 0},
            "%CPU": {"user": 0, "system": 0, "idle": 0},
            "KiB Mem": {"total": 0, "free": 0, "used": 0},
            "KiB Swap": {"total": 0, "free": 0, "used": 0},
            "Timestamp": 0}
    _CONVERSION = 0.0009765625
    
    def __init__(self):
        self.get_tasks()
        self.get_cpu_percent()
        self.get_mem()
        self.get_swap()
        self.get_timestamp()
    
    
    
    def get_tasks(self):
        for proc in psutil.process_iter(['status']):
          match proc.info['status']:
              case "running":
                  self.snap["Tasks"]["running"] += 1
              case "sleeping":
                  self.snap["Tasks"]["sleeping"] += 1
              case "stopped":
                  self.snap["Tasks"]["stopped"] += 1
              case "zombie":
                  self.snap["Tasks"]["zombie"] += 1
              case _:
                  pass
          self.snap["Tasks"]["total"] += 1    

    def get_cpu_percent(self):
        p = psutil.cpu_times_percent()
    
        self.snap["%CPU"]["user"] = p[0]
        self.snap["%CPU"]["system"] = p[2]
        self.snap["%CPU"]["idle"] = p[3]

    def get_mem(self):
        global _CONVERSION
        p = psutil.virtual_memory()
        
        self.snap["KiB Mem"]["total"] = int(p[0] * self._CONVERSION)
        self.snap["KiB Mem"]["free"] = int(p[4] * self._CONVERSION)
        self.snap["KiB Mem"]["used"] = int(p[3] * self._CONVERSION)

    def get_swap(self):
        global _CONVERSION
        p = psutil.swap_memory()

        self.snap["KiB Swap"]["total"] = int(p[0] * self._CONVERSION)
        self.snap["KiB Swap"]["free"] = int(p[2] * self._CONVERSION)
        self.snap["KiB Swap"]["used"] = int(p[1] * self._CONVERSION)

    def get_timestamp(self):
        self.snap["Timestamp"] = int(psutil.boot_time())

    def __str__(self):
        res = ''
        for line in self.snap.items():
            res += str(line) + "\n"
        return res

def main():
    """Snapshot tool."""
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", help="Interval between snapshots in seconds", type=int, default=30)
    parser.add_argument("-f", help="Output file name", default="snapshot.json")
    parser.add_argument("-n", help="Quantity of snapshot to output",type=int, default=20)
    args = parser.parse_args()
    
    with open(args.f, "w") as file:
        for _ in range(args.n):
            snap = CreateSnap()
            out = json.dumps(snap.snap)
            file.write(out)
            file.write("\n")
            os.system("clear")
            print(snap, end="\r")
            print()
            time.sleep(args.i)        
    

if __name__ == "__main__":
    main()
