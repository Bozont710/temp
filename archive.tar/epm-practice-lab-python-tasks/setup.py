from setuptools import setup, find_packages

setup(
  name='snapshot',
  version='0.1',
  description='creates system snapshots',
  install_requires=['argparse', 'psutil'],
  py_modules=['json', 'os', 'time'],
  packages=find_packages(),
  entry_points={
    "console_scripts": [
      "snapshot = snapshot.snapshot:main"
    ]
  }
)